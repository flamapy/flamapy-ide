from typing import cast, Any, Callable

from flamapy.core.models import VariabilityModel
from flamapy.metamodels.configuration_metamodel.models import Configuration
from flamapy.metamodels.fm_metamodel.models import FeatureModel
from flamapy.metamodels.fm_metamodel.operations.interfaces import EvaluateAttribute


class FMEvaluateAttribute(EvaluateAttribute):

    def __init__(self) -> None:
        self.result: Any = None
        self.configuration = Configuration(elements={})
        self.attribute: str = ''

    def set_configuration(self, configuration: Configuration) -> None:
        self.configuration = configuration

    def set_attribute(self, attribute_name: str) -> None:
        self.attribute = attribute_name

    def get_result(self) -> Any:
        return self.result

    def execute(self, model: VariabilityModel) -> 'FMEvaluateAttribute':
        fm_model = cast(FeatureModel, model)
        self.result = attribute_value(fm_model, self.configuration, self.attribute)
        return self

    def get_attribute_value(self) -> Any:
        return self.get_result()


def attribute_value(feature_model: FeatureModel,
                    configuration: Configuration,
                    attribute_name: str,
                    aggregator: Callable = sum) -> Any:
    """
    Computes the value of a given attribute in a configuration by applying 
    the specified aggregator function (e.g., sum, product, max) to the 
    attribute values of all selected features in the feature model.
    """
    values = []
    for feature_name in configuration.get_selected_elements():
        feature = feature_model.get_feature_by_name(feature_name)
        attribute = next((attr for attr in feature.attributes if attr.name == attribute_name),
                         None)
        if attribute is not None:
            values.append(attribute.get_default_value())
    return aggregator(values)
